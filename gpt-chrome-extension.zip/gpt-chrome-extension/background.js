// background.js
console.log("Background service worker loaded.");
